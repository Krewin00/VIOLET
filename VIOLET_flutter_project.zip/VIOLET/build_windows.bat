@echo off
flutter pub get
flutter config --enable-windows-desktop
flutter build windows --release
pause
