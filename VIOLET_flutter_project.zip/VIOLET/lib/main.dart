import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF09080D);
const panel = Color(0xFF15121D);
const panel2 = Color(0xFF211A2C);
const violet = Color(0xFF9B5CFF);
const lilac = Color(0xFFD3B8FF);
const muted = Color(0xFF9A92A7);

void main() => runApp(const VioletApp());

class Track {
  final String title;
  final String artist;
  final String path;
  final bool local;
  const Track(this.title, this.artist, this.path, {this.local = false});
}

class VioletApp extends StatefulWidget {
  const VioletApp({super.key});
  @override
  State<VioletApp> createState() => _VioletAppState();
}

class _VioletAppState extends State<VioletApp> {
  final AudioPlayer player = AudioPlayer();
  final List<Track> tracks = [];
  final Set<String> liked = {};
  int tab = 0;
  int current = -1;
  double speed = 1;
  bool shuffle = false;
  LoopMode loop = LoopMode.off;
  String mood = 'Любое настроение';
  bool loading = false;

  @override
  void initState() {
    super.initState();
    _loadLibrary();
    player.playerStateStream.listen((_) { if (mounted) setState(() {}); });
    player.positionStream.listen((_) { if (mounted) setState(() {}); });
    player.durationStream.listen((_) { if (mounted) setState(() {}); });
  }

  Future<void> _loadLibrary() async {
    final p = await SharedPreferences.getInstance();
    final saved = p.getStringList('violet_paths') ?? [];
    for (final path in saved) {
      final f = File(path);
      if (await f.exists()) {
        tracks.add(Track(_fileTitle(path), 'Локальный файл', path, local: true));
      }
    }
    if (mounted) setState(() {});
  }

  String _fileTitle(String path) {
    final name = path.split(Platform.pathSeparator).last;
    return name.replaceAll(RegExp(r'\.[^.]+$'), '');
  }

  Future<void> _saveLibrary() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList('violet_paths', tracks.map((e) => e.path).toList());
  }

  Future<void> _addFiles() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio, allowMultiple: true, withData: false,
    );
    if (result == null) return;
    for (final f in result.files) {
      if (f.path == null) continue;
      tracks.add(Track(_fileTitle(f.path!), 'Локальный файл', f.path!, local: true));
    }
    await _saveLibrary();
    if (mounted) setState(() {});
  }

  Future<void> _play(int index) async {
    if (index < 0 || index >= tracks.length) return;
    setState(() { current = index; loading = true; });
    try {
      await player.setFilePath(tracks[index].path);
      await player.setSpeed(speed);
      await player.play();
    } catch (e) {
      _snack('Не удалось воспроизвести файл: $e');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _snack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), backgroundColor: panel2),
    );
  }

  Future<void> _next() async {
    if (tracks.isEmpty) return;
    final next = shuffle
        ? (DateTime.now().microsecondsSinceEpoch % tracks.length)
        : (current + 1) % tracks.length;
    await _play(next);
  }

  Future<void> _previous() async {
    if (tracks.isEmpty) return;
    if (player.position > const Duration(seconds: 3)) {
      await player.seek(Duration.zero);
    } else {
      await _play((current - 1 + tracks.length) % tracks.length);
    }
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VIOLET',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(primary: violet, surface: panel),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: LayoutBuilder(builder: (context, constraints) {
        final wide = constraints.maxWidth >= 760;
        return Scaffold(
          body: Row(children: [
            if (wide) _sidebar(),
            Expanded(child: Column(children: [
              _topBar(wide),
              Expanded(child: _page()),
              if (current >= 0) _miniPlayer(),
              if (!wide) _bottomNav(),
            ])),
          ]),
        );
      }),
    );
  }

  Widget _sidebar() => Container(
    width: 224, color: const Color(0xFF0E0B14),
    padding: const EdgeInsets.fromLTRB(20, 28, 14, 20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _brand(),
      const SizedBox(height: 42),
      _navItem(Icons.home_rounded, 'Главная', 0),
      _navItem(Icons.search_rounded, 'Поиск', 1),
      _navItem(Icons.waves_rounded, 'Моя волна', 2),
      _navItem(Icons.library_music_rounded, 'Библиотека', 3),
      const Spacer(),
      const Text('PERSONAL MUSIC SPACE', style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1.4)),
      const SizedBox(height: 8),
      _navItem(Icons.settings_rounded, 'Настройки', 4),
    ]),
  );

  Widget _brand() => Row(children: [
    Container(width: 34, height: 34, decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(11),
      gradient: const LinearGradient(colors: [violet, Color(0xFF5521A5)])),
      child: const Icon(Icons.graphic_eq_rounded, color: Colors.white)),
    const SizedBox(width: 10),
    const Text('VIOLET', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 2.2)),
  ]);

  Widget _topBar(bool wide) => Padding(
    padding: EdgeInsets.fromLTRB(wide ? 28 : 20, 22, 20, 12),
    child: Row(children: [
      if (!wide) _brand() else Text(
        ['Твоя музыка', 'Поиск', 'Моя волна', 'Библиотека', 'Настройки'][tab],
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const Spacer(),
      Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(30)),
        child: const Row(children: [
          Icon(Icons.circle, color: Color(0xFF66D69B), size: 8),
          SizedBox(width: 7),
          Text('PERSONAL SPACE', style: TextStyle(color: muted, fontSize: 9, letterSpacing: 1)),
        ])),
    ]),
  );

  Widget _page() {
    switch (tab) {
      case 1: return _searchPage();
      case 2: return _wavePage();
      case 3: return _libraryPage();
      case 4: return _settingsPage();
      default: return _homePage();
    }
  }

  Widget _homePage() => ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 24), children: [
    _hero(),
    const SizedBox(height: 28),
    _sectionTitle('Быстрый доступ', 'ТВОЯ КОЛЛЕКЦИЯ'),
    const SizedBox(height: 13),
    Wrap(spacing: 10, runSpacing: 10, children: [
      _quickCard(Icons.favorite_rounded, 'Мне нравится', '${liked.length} треков', () => setState(() => tab = 3)),
      _quickCard(Icons.library_music_rounded, 'Моя музыка', '${tracks.length} треков', () => setState(() => tab = 3)),
    ]),
    const SizedBox(height: 28),
    _sectionTitle('Недавно добавлено', 'LOCAL LIBRARY'),
    const SizedBox(height: 12),
    if (tracks.isEmpty) _emptyState('Твоя библиотека пока пуста', 'Добавь аудиофайлы с устройства, чтобы начать слушать.', Icons.headphones_rounded)
    else ...tracks.take(5).toList().asMap().entries.map((e) => _trackTile(e.value, e.key)),
    const SizedBox(height: 24),
    _sectionTitle('Выбери настроение', 'MOOD SELECTION'),
    const SizedBox(height: 12),
    Wrap(spacing: 8, runSpacing: 8, children: ['Спокойствие', 'Энергия', 'Ночь', 'Фокус', 'Открытия'].map((m) =>
      ChoiceChip(label: Text(m), selected: mood == m, onSelected: (_) => setState(() { mood = m; tab = 2; }),
        selectedColor: violet.withOpacity(.28), backgroundColor: panel, side: BorderSide.none)).toList()),
  ]);

  Widget _hero() => Container(
    height: 218, padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(26),
      gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
        colors: [Color(0xFF3C1B67), Color(0xFF1D1230), Color(0xFF100D18)]),
      border: Border.all(color: violet.withOpacity(.25)),
    ),
    child: Stack(children: [
      Positioned(right: -18, top: -28, child: Icon(Icons.graphic_eq_rounded, size: 190, color: Colors.white.withOpacity(.07))),
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('ТВОЁ ЗВУЧАНИЕ', style: TextStyle(color: lilac, fontSize: 10, letterSpacing: 2, fontWeight: FontWeight.w700)),
        const Spacer(),
        const Text('Музыка.\\nТолько твоя.', style: TextStyle(fontSize: 30, height: 1.08, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('Собери пространство под своё настроение', style: TextStyle(color: Color(0xFFC8BBD8), fontSize: 12)),
        const SizedBox(height: 15),
        FilledButton.icon(onPressed: _addFiles, icon: const Icon(Icons.add, size: 18),
          label: const Text('Добавить музыку'),
          style: FilledButton.styleFrom(backgroundColor: violet, foregroundColor: Colors.white)),
      ]),
    ]),
  );

  Widget _sectionTitle(String title, String eyebrow) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(eyebrow, style: const TextStyle(color: violet, fontSize: 9, letterSpacing: 1.8, fontWeight: FontWeight.w800)),
    const SizedBox(height: 5),
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
  ]);

  Widget _quickCard(IconData icon, String title, String subtitle, VoidCallback onTap) => InkWell(
    onTap: onTap, borderRadius: BorderRadius.circular(16),
    child: Container(width: 174, padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.04))),
      child: Row(children: [
        Container(width: 40, height: 40, decoration: BoxDecoration(color: violet.withOpacity(.17), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: lilac)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
          Text(subtitle, style: const TextStyle(color: muted, fontSize: 10)),
        ])),
      ]),
    ),
  );

  Widget _searchPage() {
    return Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      TextField(
        onChanged: (_) => setState(() {}),
        decoration: InputDecoration(
          hintText: 'Треки и исполнители в твоей библиотеке',
          prefixIcon: const Icon(Icons.search, color: lilac),
          filled: true, fillColor: panel,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 22),
      _sectionTitle('Твоя музыка', 'SEARCH LOCAL FILES'),
      const SizedBox(height: 12),
      Expanded(child: tracks.isEmpty
        ? _emptyState('Пока нечего искать', 'Добавь локальные аудиофайлы.', Icons.search_rounded)
        : ListView(children: tracks.asMap().entries.map((e) => _trackTile(e.value, e.key)).toList())),
    ]));
  }

  Widget _wavePage() => ListView(padding: const EdgeInsets.all(20), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(24),
      gradient: const LinearGradient(colors: [Color(0xFF43206E), Color(0xFF171020)])),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.waves_rounded, size: 38, color: lilac),
        const SizedBox(height: 14),
        const Text('МОЯ ВОЛНА', style: TextStyle(fontSize: 11, letterSpacing: 2, color: lilac, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Звучание твоего момента', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('Выбери настроение. VIOLET соберёт подходящую подборку из твоей библиотеки.', style: TextStyle(color: Color(0xFFC8BBD8), height: 1.4)),
      ]),
    ),
    const SizedBox(height: 24),
    _sectionTitle('Как ты себя чувствуешь?', 'CHOOSE YOUR MOOD'),
    const SizedBox(height: 14),
    ...[
      ('Спокойствие', 'Мягкое и ненавязчивое звучание', Icons.spa_rounded),
      ('Энергия', 'Больше ритма и движения', Icons.bolt_rounded),
      ('Ночь', 'Атмосферные вечерние треки', Icons.nightlight_round),
      ('Фокус', 'Музыка для концентрации', Icons.center_focus_strong_rounded),
      ('Открытия', 'Случайный выбор из твоей коллекции', Icons.explore_rounded),
    ].map((item) => _moodTile(item.$1, item.$2, item.$3)),
    const SizedBox(height: 16),
    Text('Сейчас: $mood', style: const TextStyle(color: lilac, fontWeight: FontWeight.w700)),
    const SizedBox(height: 10),
    if (tracks.isNotEmpty) _trackTile(tracks[DateTime.now().second % tracks.length], DateTime.now().second % tracks.length),
    if (tracks.isEmpty) _emptyState('Нужна музыкальная библиотека', 'Добавь свои аудиофайлы. Пока рекомендациям не из чего выбирать.', Icons.library_music_rounded),
  ]);

  Widget _moodTile(String title, String subtitle, IconData icon) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: InkWell(onTap: () => setState(() => mood = title), borderRadius: BorderRadius.circular(15),
      child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(
        color: mood == title ? violet.withOpacity(.18) : panel, borderRadius: BorderRadius.circular(15),
        border: Border.all(color: mood == title ? violet.withOpacity(.55) : Colors.white.withOpacity(.04))),
        child: Row(children: [
          Icon(icon, color: lilac, size: 23), const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
          ])),
          if (mood == title) const Icon(Icons.check_circle, color: lilac, size: 19),
        ]),
      )),
  );

  Widget _libraryPage() => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(20, 8, 20, 14), child: Row(children: [
      Expanded(child: _sectionTitle('Твоя библиотека', 'YOUR COLLECTION')),
      IconButton.filled(onPressed: _addFiles, icon: const Icon(Icons.add), style: IconButton.styleFrom(backgroundColor: violet)),
    ])),
    Expanded(child: tracks.isEmpty
      ? _emptyState('Здесь пока тихо', 'Нажми + и добавь музыку с устройства.', Icons.library_music_rounded)
      : ListView(padding: const EdgeInsets.symmetric(horizontal: 20), children: [
        _quickCard(Icons.favorite, 'Избранное', '${liked.length} треков', () => setState(() {})),
        const SizedBox(height: 14),
        ...tracks.asMap().entries.map((e) => _trackTile(e.value, e.key)),
      ])),
  ]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(20), children: [
    _sectionTitle('Настройки', 'PERSONALIZATION'),
    const SizedBox(height: 18),
    _settingRow(Icons.speed_rounded, 'Скорость воспроизведения', '${speed.toStringAsFixed(2)}×'),
    Slider(value: speed, min: .75, max: 2, divisions: 25, activeColor: violet,
      onChanged: (v) async { setState(() => speed = v); await player.setSpeed(v); }),
    _settingRow(Icons.shuffle_rounded, 'Перемешивание', shuffle ? 'Включено' : 'Выключено',
      trailing: Switch(value: shuffle, activeColor: violet, onChanged: (v) => setState(() => shuffle = v))),
    _settingRow(Icons.repeat_rounded, 'Повтор', loop == LoopMode.off ? 'Выключен' : loop == LoopMode.one ? 'Один трек' : 'Весь список',
      trailing: IconButton(onPressed: () => setState(() {
        loop = loop == LoopMode.off ? LoopMode.all : loop == LoopMode.all ? LoopMode.one : LoopMode.off;
        player.setLoopMode(loop);
      }), icon: const Icon(Icons.repeat, color: lilac))),
    const SizedBox(height: 20),
    const Text('VIOLET 0.1.0 • PERSONAL MUSIC SPACE', style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.2)),
    const SizedBox(height: 8),
    const Text('Сейчас приложение воспроизводит локальные аудиофайлы. Подключение Spotify и SoundCloud требует отдельной авторизации и поддержки API.', style: TextStyle(color: muted, height: 1.5, fontSize: 12)),
  ]);

  Widget _settingRow(IconData icon, String title, String value, {Widget? trailing}) => Row(children: [
    Icon(icon, color: lilac), const SizedBox(width: 12),
    Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600))),
    if (trailing != null) trailing else Text(value, style: const TextStyle(color: muted)),
  ]);

  Widget _trackTile(Track track, int index) {
    final isCurrent = current == index;
    return Padding(padding: const EdgeInsets.only(bottom: 8), child: InkWell(
      onTap: () => _play(index), borderRadius: BorderRadius.circular(14),
      child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(
        color: isCurrent ? violet.withOpacity(.13) : panel, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Container(width: 45, height: 45, decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(11),
            gradient: LinearGradient(colors: [violet.withOpacity(.75), const Color(0xFF29163D)])),
            child: Icon(isCurrent ? Icons.equalizer_rounded : Icons.music_note_rounded, color: Colors.white)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.w700, color: isCurrent ? lilac : Colors.white)),
            Text(track.artist, style: const TextStyle(color: muted, fontSize: 11)),
          ])),
          IconButton(onPressed: () => setState(() {
            if (liked.contains(track.path)) { liked.remove(track.path); } else { liked.add(track.path); }
          }), icon: Icon(liked.contains(track.path) ? Icons.favorite : Icons.favorite_border,
            color: liked.contains(track.path) ? violet : muted, size: 20)),
          IconButton(onPressed: () => _play(index), icon: Icon(isCurrent && player.playing ? Icons.pause : Icons.play_arrow,
            color: lilac)),
        ]),
      ),
    ));
  }

  Widget _emptyState(String title, String subtitle, IconData icon) => ExpandedIfNeeded(child: Center(
    child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 48, color: violet.withOpacity(.7)),
      const SizedBox(height: 14),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
      const SizedBox(height: 7),
      Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: muted, height: 1.4, fontSize: 12)),
    ])),
  ));

  Widget _bottomNav() => Container(
    decoration: BoxDecoration(color: const Color(0xFF100D15), border: Border(top: BorderSide(color: Colors.white.withOpacity(.06)))),
    padding: const EdgeInsets.only(top: 7, bottom: 8),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
      _bottomItem(Icons.home_rounded, 'Главная', 0),
      _bottomItem(Icons.search_rounded, 'Поиск', 1),
      _bottomItem(Icons.waves_rounded, 'Волна', 2),
      _bottomItem(Icons.library_music_rounded, 'Библиотека', 3),
      _bottomItem(Icons.settings_rounded, 'Настройки', 4),
    ]),
  );

  Widget _bottomItem(IconData icon, String label, int index) => InkWell(
    onTap: () => setState(() => tab = index),
    child: SizedBox(width: 64, child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: tab == index ? lilac : muted, size: 21),
      const SizedBox(height: 3),
      Text(label, style: TextStyle(fontSize: 9, color: tab == index ? lilac : muted)),
    ])),
  );

  Widget _navItem(IconData icon, String label, int index) => Padding(
    padding: const EdgeInsets.only(bottom: 7),
    child: InkWell(onTap: () => setState(() => tab = index), borderRadius: BorderRadius.circular(12),
      child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        decoration: BoxDecoration(color: tab == index ? violet.withOpacity(.17) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
        child: Row(children: [
          Icon(icon, color: tab == index ? lilac : muted, size: 19),
          const SizedBox(width: 12),
          Text(label, style: TextStyle(color: tab == index ? Colors.white : muted, fontWeight: tab == index ? FontWeight.w700 : FontWeight.w500)),
        ]),
      )),
  );

  Widget _miniPlayer() {
    final track = current >= 0 && current < tracks.length ? tracks[current] : null;
    if (track == null) return const SizedBox.shrink();
    final duration = player.duration ?? Duration.zero;
    final position = player.position;
    final max = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
    return InkWell(onTap: _openPlayer, child: Container(
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 8), padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      decoration: BoxDecoration(color: const Color(0xFF21182D), borderRadius: BorderRadius.circular(16),
        border: Border.all(color: violet.withOpacity(.3))),
      child: Column(children: [
        Row(children: [
          Container(width: 37, height: 37, decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(9), gradient: const LinearGradient(colors: [violet, Color(0xFF351A55)])),
            child: const Icon(Icons.music_note, color: Colors.white)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
            Text(track.artist, style: const TextStyle(color: muted, fontSize: 10)),
          ])),
          IconButton(onPressed: _previous, icon: const Icon(Icons.skip_previous_rounded, color: lilac)),
          IconButton(onPressed: () => player.playing ? player.pause() : player.play(),
            icon: Icon(player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white, size: 27)),
          IconButton(onPressed: _next, icon: const Icon(Icons.skip_next_rounded, color: lilac)),
        ]),
        LinearProgressIndicator(value: (position.inMilliseconds / max).clamp(0, 1),
          minHeight: 2, backgroundColor: Colors.white10, color: violet),
      ]),
    ));
  }

  void _openPlayer() {
    showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: bg,
      builder: (_) => StatefulBuilder(builder: (context, modalSet) {
        final track = current >= 0 && current < tracks.length ? tracks[current] : null;
        if (track == null) return const SizedBox.shrink();
        final duration = player.duration ?? Duration.zero;
        final position = player.position;
        return SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24, 18, 24, 24),
          child: SizedBox(height: MediaQuery.of(context).size.height * .78, child: Column(children: [
            Container(width: 38, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(5))),
            const Spacer(),
            Container(width: 240, height: 240, decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFB47AFF), Color(0xFF3A1761), Color(0xFF130D1C)]),
              boxShadow: [BoxShadow(color: violet.withOpacity(.25), blurRadius: 35, spreadRadius: 2)]),
              child: const Icon(Icons.graphic_eq_rounded, size: 100, color: Colors.white70)),
            const SizedBox(height: 28),
            Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            Text(track.artist, style: const TextStyle(color: muted)),
            const SizedBox(height: 25),
            Slider(value: duration.inMilliseconds == 0 ? 0 : position.inMilliseconds.clamp(0, duration.inMilliseconds).toDouble(),
              min: 0, max: duration.inMilliseconds <= 0 ? 1 : duration.inMilliseconds.toDouble(),
              activeColor: violet, onChanged: (v) => player.seek(Duration(milliseconds: v.toInt()))),
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Text(_time(position), style: const TextStyle(color: muted, fontSize: 10)),
              Text(_time(duration), style: const TextStyle(color: muted, fontSize: 10)),
            ]),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(onPressed: () => setState(() => shuffle = !shuffle), icon: Icon(Icons.shuffle, color: shuffle ? lilac : muted)),
              IconButton(onPressed: _previous, icon: const Icon(Icons.skip_previous_rounded, size: 38)),
              Container(width: 64, height: 64, decoration: const BoxDecoration(color: violet, shape: BoxShape.circle),
                child: IconButton(onPressed: () { player.playing ? player.pause() : player.play(); modalSet(() {}); },
                  icon: Icon(player.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 34, color: Colors.white))),
              IconButton(onPressed: _next, icon: const Icon(Icons.skip_next_rounded, size: 38)),
              IconButton(onPressed: () { setState(() { loop = loop == LoopMode.off ? LoopMode.all : loop == LoopMode.all ? LoopMode.one : LoopMode.off; player.setLoopMode(loop); }); },
                icon: Icon(Icons.repeat, color: loop == LoopMode.off ? muted : lilac)),
            ]),
            const SizedBox(height: 18),
            Row(children: [
              const Icon(Icons.speed, color: lilac),
              const SizedBox(width: 10),
              const Text('Скорость'),
              Expanded(child: Slider(value: speed, min: .75, max: 2, divisions: 25, activeColor: violet,
                onChanged: (v) async { setState(() => speed = v); await player.setSpeed(v); modalSet(() {}); })),
              Text('${speed.toStringAsFixed(2)}×', style: const TextStyle(color: lilac, fontWeight: FontWeight.w700)),
            ]),
            const Spacer(),
          ]))));
      }),
    );
  }

  String _time(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }
}

class ExpandedIfNeeded extends StatelessWidget {
  final Widget child;
  const ExpandedIfNeeded({super.key, required this.child});
  @override
  Widget build(BuildContext context) => child;
}
