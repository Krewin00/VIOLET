@echo off
flutter create --platforms=android,windows --project-name violet .
if errorlevel 1 pause & exit /b 1
flutter pub get
pause
